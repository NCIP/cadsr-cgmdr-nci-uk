var dependencies = [
    "dojo.event.*",
    "chiba.widget.Boolean"    
];

dependencies.prefixes = [
   ["chiba", "../chiba-web/web/resources/scripts/chiba"]
];

load("getDependencyList.js");

