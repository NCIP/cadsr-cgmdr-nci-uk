dojo.provide("chiba.manifest");
dojo.registerNamespaceResolver(function(name) {
  return "chiba.widgets.variousWidgets";
});