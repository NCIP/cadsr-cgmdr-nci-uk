/*
 *
 *    Artistic License
 *
 *    Preamble
 *
 *    The intent of this document is to state the conditions under which a Package may be copied, such that
 *    the Copyright Holder maintains some semblance of artistic control over the development of the
 *    package, while giving the users of the package the right to use and distribute the Package in a
 *    more-or-less customary fashion, plus the right to make reasonable modifications.
 *
 *    Definitions:
 *
 *    "Package" refers to the collection of files distributed by the Copyright Holder, and derivatives
 *    of that collection of files created through textual modification.
 *
 *    "Standard Version" refers to such a Package if it has not been modified, or has been modified
 *    in accordance with the wishes of the Copyright Holder.
 *
 *    "Copyright Holder" is whoever is named in the copyright or copyrights for the package.
 *
 *    "You" is you, if you're thinking about copying or distributing this Package.
 *
 *    "Reasonable copying fee" is whatever you can justify on the basis of media cost, duplication
 *    charges, time of people involved, and so on. (You will not be required to justify it to the
 *    Copyright Holder, but only to the computing community at large as a market that must bear the
 *    fee.)
 *
 *    "Freely Available" means that no fee is charged for the item itself, though there may be fees
 *    involved in handling the item. It also means that recipients of the item may redistribute it under
 *    the same conditions they received it.
 *
 *    1. You may make and give away verbatim copies of the source form of the Standard Version of this
 *    Package without restriction, provided that you duplicate all of the original copyright notices and
 *    associated disclaimers.
 *
 *    2. You may apply bug fixes, portability fixes and other modifications derived from the Public Domain
 *    or from the Copyright Holder. A Package modified in such a way shall still be considered the
 *    Standard Version.
 *
 *    3. You may otherwise modify your copy of this Package in any way, provided that you insert a
 *    prominent notice in each changed file stating how and when you changed that file, and provided that
 *    you do at least ONE of the following:
 *
 *        a) place your modifications in the Public Domain or otherwise make them Freely
 *        Available, such as by posting said modifications to Usenet or an equivalent medium, or
 *        placing the modifications on a major archive site such as ftp.uu.net, or by allowing the
 *        Copyright Holder to include your modifications in the Standard Version of the Package.
 *
 *        b) use the modified Package only within your corporation or organization.
 *
 *        c) rename any non-standard executables so the names do not conflict with standard
 *        executables, which must also be provided, and provide a separate manual page for each
 *        non-standard executable that clearly documents how it differs from the Standard
 *        Version.
 *
 *        d) make other distribution arrangements with the Copyright Holder.
 *
 *    4. You may distribute the programs of this Package in object code or executable form, provided that
 *    you do at least ONE of the following:
 *
 *        a) distribute a Standard Version of the executables and library files, together with
 *        instructions (in the manual page or equivalent) on where to get the Standard Version.
 *
 *        b) accompany the distribution with the machine-readable source of the Package with
 *        your modifications.
 *
 *        c) accompany any non-standard executables with their corresponding Standard Version
 *        executables, giving the non-standard executables non-standard names, and clearly
 *        documenting the differences in manual pages (or equivalent), together with instructions
 *        on where to get the Standard Version.
 *
 *        d) make other distribution arrangements with the Copyright Holder.
 *
 *    5. You may charge a reasonable copying fee for any distribution of this Package. You may charge
 *    any fee you choose for support of this Package. You may not charge a fee for this Package itself.
 *    However, you may distribute this Package in aggregate with other (possibly commercial) programs as
 *    part of a larger (possibly commercial) software distribution provided that you do not advertise this
 *    Package as a product of your own.
 *
 *    6. The scripts and library files supplied as input to or produced as output from the programs of this
 *    Package do not automatically fall under the copyright of this Package, but belong to whomever
 *    generated them, and may be sold commercially, and may be aggregated with this Package.
 *
 *    7. C or perl subroutines supplied by you and linked into this Package shall not be considered part of
 *    this Package.
 *
 *    8. The name of the Copyright Holder may not be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 *    9. THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 *    MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */
package org.chiba.xml.xforms;

import org.apache.log4j.Logger;
import org.apache.xerces.dom.ElementImpl;
import org.chiba.xml.ns.NamespaceConstants;
import org.chiba.xml.xforms.config.Config;
import org.chiba.xml.xforms.config.XFormsConfigException;
import org.chiba.xml.xforms.core.Model;
import org.chiba.xml.xforms.exception.XFormsException;
import org.w3c.dom.Element;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 * CustomElementFactory creates objects for all elements in the input Document
 * that match a namespace/element name retrieved from the configuration.
 * 
 * @author <a href="mailto:flaviocosta@users.sourceforge.net">Flavio Costa </a>
 */
public class CustomElementFactory implements XFormsConstants {

	/**
	 * The logger.
	 */
	private static Logger LOGGER = Logger.getLogger(Config.class);

	/**
	 * Holds the configuration for custom elements.
	 */
	private static final Map ELEMENTS = getCustomElementsConfig();

	/**
	 * Used to quickly check if there are custom elements or not.
	 */
	private boolean noCustomElements;

	/**
	 * Loads the configuration for custom elements.
	 * 
	 * @return A Map where the keys are in the format namespace-uri:element-name
	 *         and the value is the reference to the class that implements the
	 *         custom element, or an empty map if the configuration could not be
	 *         loaded for some reason.
	 */
	private static Map getCustomElementsConfig() {

		try {
			Map elementClassNames = Config.getInstance().getCustomElements();
			Map elementClassRefs = new HashMap(elementClassNames.size());

			Iterator itr = elementClassNames.entrySet().iterator();

			//converts class names into the class references
			while (itr.hasNext()) {

				Map.Entry entry = (Entry) itr.next();

				String key = (String) entry.getKey();
				String className = (String) entry.getValue();
				Class classRef = Class.forName(className);

				elementClassRefs.put(key, classRef);
			}

			//return the configuration
			return elementClassRefs;

		} catch (XFormsConfigException xfce) {
			LOGGER.error("could not load custom-elements config: "
					+ xfce.getMessage());

		} catch (ClassNotFoundException cnfe) {
			LOGGER.error("class configured for custom-element not found: "
					+ cnfe.getMessage());
		}

		//returns an empty map (no custom elements)
		return Collections.EMPTY_MAP;
	}

	/**
	 * Creates a new CustomElementFactory object.
	 */
	public CustomElementFactory() throws XFormsException {
		this.noCustomElements = ELEMENTS.isEmpty();
	}

	/**
	 * Given an element, generate a key used to find objects in ELEMENTS.
	 * 
	 * @param element
	 *            Element whose configuration is to be looked for.
	 * 
	 * @return The key corresponding to the element definition.
	 */
	public String getKeyForElement(Element element) {
		return element.getNamespaceURI() + ":" + element.getLocalName();
	}

	/**
	 * Returns true if the given DOM Element matches a configured custom
	 * element.
	 * 
	 * @param element
	 *            The DOM Element to investigate.
	 * @return Whether the element matches a custom element or not.
	 * 
	 * @throws XFormsException
	 *             In case of MustUnderstand Module failure.
	 */
	public boolean isCustomElement(Element element) throws XFormsException {

		if (this.noCustomElements) {
			//no custom elements configured
			return false;
		}

		//key to search the Map for a custom element
		String key = getKeyForElement(element);

		if (ELEMENTS.containsKey(key)) {
			//a match was found
			return true;
		}

		//if the element is not recognized but it has a
		//mustUnderstand attribute, throw an exception to
		//signal error according to the spec
		if (element.hasAttributeNS(NamespaceConstants.XFORMS_NS,
				MUST_UNDERSTAND_ATTRIBUTE)) {

			String elementId = element.getPrefix() + ":"
					+ element.getLocalName();

			throw new XFormsException(
					"MustUnderstand Module failure at element " + elementId);
		}

		//no matching configuration was found
		return false;
	}

	/**
	 * Factory method for custom element implementations.
	 * 
	 * @param element
	 *            The DOM Element which will be annotated.
	 * @param model
	 *            The owning model.
	 * @return The created object.
	 */
	public XFormsElement createCustomXFormsElement(Element element, Model model)
			throws XFormsException {

		//gets the class reference
		String key = getKeyForElement(element);
		Class elementClazz = (Class) ELEMENTS.get(key);

		//this should never happen
		if (elementClazz == null) {
			throw new XFormsException("No class defined for " + key);
		}

		XFormsElement xformsElement = null;

		if (elementClazz != null) {
			try {
				//initializes a new object from the class
				xformsElement = (XFormsElement) elementClazz.getConstructor(
						new Class[]{Element.class, Model.class}).newInstance(
						new Object[]{(Element) element, model});

			} catch (Exception e) {
				throw new XFormsException(e);
			}

			((ElementImpl) element).setUserData(xformsElement);
		}

		return xformsElement;
	}
}